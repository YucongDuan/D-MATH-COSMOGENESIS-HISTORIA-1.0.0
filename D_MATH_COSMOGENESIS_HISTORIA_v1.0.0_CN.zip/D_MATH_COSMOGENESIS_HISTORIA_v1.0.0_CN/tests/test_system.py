
import json, tempfile, unittest
from pathlib import Path
from dmath_cosmogenesis_historia.examples import worlds
from dmath_cosmogenesis_historia.core import analyze_world, quotient
from dmath_cosmogenesis_historia.theorems import run_checks
from dmath_cosmogenesis_historia.runtime import run_demo, verify_run

class TestSystem(unittest.TestCase):
    def test_refinement(self):
        w=worlds(); self.assertGreaterEqual(len(quotient(w['latent_split_after'],4)[0]),len(quotient(w['latent_split_before'],4)[0]))
    def test_time_arrow(self):
        w=worlds(); self.assertEqual(analyze_world(w['reversible_ring']).time_atlas['irreversible_edge_ratio'],0.0); self.assertGreater(analyze_world(w['dissipative_funnel']).time_atlas['distinction_erasure_bits'],0)
    def test_theorems(self): self.assertTrue(all(x['passed'] for x in run_checks(worlds())))
    def test_demo_ledger(self):
        with tempfile.TemporaryDirectory() as td:
            r=run_demo(Path(td)); self.assertEqual(r['summary']['theorems_passed'],12); self.assertTrue(verify_run(Path(td))['passed'])
if __name__=='__main__': unittest.main()
