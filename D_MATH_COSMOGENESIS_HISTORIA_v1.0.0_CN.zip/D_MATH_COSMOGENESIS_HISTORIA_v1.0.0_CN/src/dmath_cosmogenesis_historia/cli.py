
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from .runtime import run_demo, analyze_file, verify_run
from .examples import worlds
from .theorems import run_checks

def main(argv=None):
    p=argparse.ArgumentParser(prog='cosmohistoria'); p.add_argument('--version',action='store_true')
    sub=p.add_subparsers(dest='cmd')
    d=sub.add_parser('demo'); d.add_argument('--out',required=True)
    a=sub.add_parser('analyze'); a.add_argument('spec'); a.add_argument('--out',required=True); a.add_argument('--depth',type=int,default=4)
    v=sub.add_parser('verify'); v.add_argument('path')
    c=sub.add_parser('conformance'); c.add_argument('--out',required=False)
    args=p.parse_args(argv)
    if args.version: print('1.0.0'); return 0
    if args.cmd=='demo':
        r=run_demo(Path(args.out)); print(json.dumps({'run_hash':r['run_hash'],'summary':r['summary']},ensure_ascii=False,indent=2)); return 0
    if args.cmd=='analyze': analyze_file(Path(args.spec),Path(args.out),args.depth); print(args.out); return 0
    if args.cmd=='verify':
        r=verify_run(Path(args.path)); print(json.dumps(r,ensure_ascii=False,indent=2)); return 0 if r['passed'] else 2
    if args.cmd=='conformance':
        th=run_checks(worlds()); result={'passed':all(t['passed'] for t in th),'checks':th,'count':len(th)}
        if args.out:
            op=Path(args.out); op.parent.mkdir(parents=True,exist_ok=True); op.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        print(json.dumps(result,ensure_ascii=False,indent=2)); return 0 if result['passed'] else 2
    p.print_help(); return 1

if __name__=='__main__': raise SystemExit(main())
