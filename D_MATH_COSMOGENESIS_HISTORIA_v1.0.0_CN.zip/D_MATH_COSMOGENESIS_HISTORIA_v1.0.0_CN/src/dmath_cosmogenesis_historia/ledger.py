
from __future__ import annotations
from dataclasses import dataclass, asdict
import hashlib, json
from pathlib import Path
from .models import canonical_json

@dataclass
class Record:
    seq: int
    event_type: str
    payload: dict
    previous_hash: str
    record_hash: str

def append(records: list[dict], event_type: str, payload: dict):
    seq=len(records)+1; prev=records[-1]["record_hash"] if records else "0"*64
    material={"seq":seq,"event_type":event_type,"payload":payload,"previous_hash":prev}
    h=hashlib.sha256(canonical_json(material).encode()).hexdigest()
    records.append({**material,"record_hash":h})

def verify(records: list[dict]):
    prev="0"*64
    for i,r in enumerate(records,1):
        if r.get("seq")!=i or r.get("previous_hash")!=prev: return {"passed":False,"failed_seq":i,"reason":"chain"}
        material={k:r[k] for k in ("seq","event_type","payload","previous_hash")}
        h=hashlib.sha256(canonical_json(material).encode()).hexdigest()
        if h!=r.get("record_hash"): return {"passed":False,"failed_seq":i,"reason":"hash"}
        prev=h
    return {"passed":True,"records":len(records),"head":prev}

def save(path: Path, records: list[dict]):
    path.write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
