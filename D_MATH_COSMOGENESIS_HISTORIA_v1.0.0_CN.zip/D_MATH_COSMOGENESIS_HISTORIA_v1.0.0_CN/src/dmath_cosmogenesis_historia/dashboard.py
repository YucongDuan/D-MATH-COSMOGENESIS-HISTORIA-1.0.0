
from __future__ import annotations
import json
from pathlib import Path

def render(data: dict, out: Path):
    blob=json.dumps(data,ensure_ascii=False).replace('</','<\\/')
    head='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>宇宙发生数学驾驶舱</title>'
    style='<style>body{font-family:system-ui,sans-serif;background:#07111f;color:#e9f1ff;margin:0}header{padding:32px 5vw;background:#102a48}main{padding:24px 5vw}.card{background:#0d2037;border:1px solid #234a6a;border-radius:12px;padding:16px;margin:12px 0}button{background:#143b5d;color:white;border:1px solid #3a769b;border-radius:8px;padding:8px 12px;margin:4px}pre{white-space:pre-wrap;max-height:540px;overflow:auto}.good{color:#75e39a}</style></head>'
    body='<body><header><h1>宇宙发生数学驾驶舱</h1><div>匿名续生 → 替换余量 → 未来同效商 → 对象、规律与图册</div></header><main><div id="summary" class="card"></div><div id="buttons"></div><div id="detail" class="card"></div><div id="theorems" class="card"></div></main>'
    js="""<script>const D=__DATA__;const s=D.summary;document.getElementById("summary").textContent=`宇宙 ${s.worlds}｜对象类 ${s.total_classes}｜区别见证 ${s.witnesses}｜元定理 ${s.theorems_passed}/${s.theorems_total}`;const B=document.getElementById("buttons");function show(i){const a=D.analyses[i];document.getElementById("detail").innerHTML="<h2>"+a.world_id+"</h2><p>对象商："+a.quotient.map(c=>"{"+c.join(", ")+"}").join(" / ")+"</p><p>不可逆边比例："+a.time_atlas.irreversible_edge_ratio.toFixed(3)+"；区别擦除："+a.time_atlas.distinction_erasure_bits.toFixed(3)+" bits；最大路径余量："+a.curvature_atlas.max_path_residual.toFixed(3)+"</p><pre>"+JSON.stringify(a.dikwp_projection,null,2)+"</pre>";}D.analyses.forEach((a,i)=>{const b=document.createElement("button");b.textContent=a.world_id;b.onclick=()=>show(i);B.appendChild(b)});show(0);document.getElementById("theorems").innerHTML="<h2>元定理</h2>"+D.theorems.map(t=>"<div class='good'>"+t.id+" · "+t.title+" · "+(t.passed?"PASS":"REOPENED")+"</div>").join("");</script></body></html>""".replace('__DATA__',blob)
    out.write_text(head+style+body+js,encoding='utf-8')
