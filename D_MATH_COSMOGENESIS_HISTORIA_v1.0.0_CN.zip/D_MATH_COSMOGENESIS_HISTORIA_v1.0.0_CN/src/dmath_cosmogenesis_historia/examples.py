
from __future__ import annotations
from .models import WorldSpec

def worlds():
    raw={
      "anonymous_seed":{
       "world_id":"anonymous_seed","states":["a0","a1","b0","b1","c0","c1"],
       "observations":{"a0":"x","a1":"x","b0":"y","b1":"y","c0":"z","c1":"z"},
       "relations":{
        "r0":{"a0":"b0","a1":"b0","b0":"c0","b1":"c1","c0":"a0","c1":"a1"},
        "r1":{"a0":"a1","a1":"a0","b0":"b1","b1":"b0","c0":"c0","c1":"c1"}},
       "purposes":["preserve future-effective differences"]},
      "latent_split_before":{
       "world_id":"latent_split_before","states":["z1","z2","y1","y2"],
       "observations":{"z1":"latent","z2":"latent","y1":"out","y2":"out"},
       "relations":{"r0":{"z1":"y1","z2":"y1","y1":"y1","y2":"y2"}}},
      "latent_split_after":{
       "world_id":"latent_split_after","states":["z1","z2","y1","y2"],
       "observations":{"z1":"latent","z2":"latent","y1":"out-A","y2":"out-B"},
       "relations":{"r0":{"z1":"y1","z2":"y1","y1":"y1","y2":"y2"},"r5":{"z1":"y1","z2":"y2","y1":"y1","y2":"y2"}}},
      "reversible_ring":{
       "world_id":"reversible_ring","states":["r0","r1","r2","r3"],"observations":{"r0":"ring","r1":"ring","r2":"ring","r3":"ring"},
       "relations":{"cw":{"r0":"r1","r1":"r2","r2":"r3","r3":"r0"},"ccw":{"r0":"r3","r3":"r2","r2":"r1","r1":"r0"}}},
      "dissipative_funnel":{
       "world_id":"dissipative_funnel","states":["s0","s1","s2","s3","s4","s5"],
       "observations":{"s0":"sink","s1":"level1","s2":"level2","s3":"level3","s4":"level4","s5":"level5"},
       "relations":{"fall":{"s0":"s0","s1":"s0","s2":"s0","s3":"s1","s4":"s1","s5":"s2"}}},
      "contextual_square":{
       "world_id":"contextual_square","states":["q0","q1","q2","q3"],"observations":{"q0":"A","q1":"B","q2":"C","q3":"D"},
       "relations":{"east":{"q0":{"target":"q1","cost":1},"q2":{"target":"q3","cost":3}},"north":{"q0":{"target":"q2","cost":1},"q1":{"target":"q3","cost":1}},"diag":{"q0":{"target":"q3","cost":4}}}},
      "reflexive_ruleworld":{
       "world_id":"reflexive_ruleworld","states":["x@R0","x@R1","y@R0","y@R1"],
       "observations":{"x@R0":"x","x@R1":"x","y@R0":"y0","y@R1":"y1"},
       "relations":{"apply":{"x@R0":"y@R0","x@R1":"y@R1","y@R0":"y@R0","y@R1":"y@R1"}}},
    }
    return {k:WorldSpec.from_dict(v) for k,v in raw.items()}
