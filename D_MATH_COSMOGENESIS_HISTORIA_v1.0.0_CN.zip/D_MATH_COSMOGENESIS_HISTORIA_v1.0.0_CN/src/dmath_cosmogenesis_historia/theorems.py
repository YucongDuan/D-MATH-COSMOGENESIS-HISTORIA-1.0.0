
from __future__ import annotations
from copy import deepcopy
from .models import WorldSpec
from .core import quotient, analyze_world, shortest_distinguishing_path

REGISTRY=[
("UM-T01","未来同效关系在声明深度上形成划分"),
("UM-T02","最小对象商保留全部已发现区别"),
("UM-T03","规律必须对对象商满足同余"),
("UM-T04","没有区别性未来就没有免费对象"),
("UM-T05","新区别关系使旧对象商细化而非无痕改写"),
("UM-T06","多对一续生生成区别擦除与时间箭头"),
("UM-T07","最小运输成本满足有向三角关系"),
("UM-T08","新增可区分关系不减少对象商信息"),
("UM-T09","匿名状态重命名不改变商结构"),
("UM-T10","D/I/K/W/P可由同一续生世界导出"),
("UM-T11","规则差异可进入对象化分析"),
("UM-T12","六类证明凭证不可互相替代"),
]

def run_checks(worlds: dict[str,WorldSpec]):
    checks=[]
    # T01
    w=worlds['anonymous_seed']; c,m,_=quotient(w,4)
    checks.append(("UM-T01",sorted(sum(c,[]))==sorted(w.states) and len(m)==len(w.states),{"classes":c}))
    # T02 distinct classes distinguishable
    ok=True
    for i in range(len(c)):
      for j in range(i+1,len(c)):
        ok=ok and shortest_distinguishing_path(w,c[i][0],c[j][0],6) is not None
    checks.append(("UM-T02",ok,{}))
    # T03
    a=analyze_world(w); checks.append(("UM-T03",a.congruence['passed'],a.congruence))
    # T04 same class no witness
    ok=True
    for cls in c:
      for x in cls:
       for y in cls:
        if shortest_distinguishing_path(w,x,y,4) is not None: ok=False
    checks.append(("UM-T04",ok,{}))
    # T05 latent refinement
    c0,_,_=quotient(worlds['latent_split_before'],4); c1,_,_=quotient(worlds['latent_split_after'],4)
    checks.append(("UM-T05",len(c1)>=len(c0),{"before":c0,"after":c1}))
    # T06
    t=analyze_world(worlds['dissipative_funnel']).time_atlas
    checks.append(("UM-T06",t['distinction_erasure_bits']>0 and t['irreversible_edge_ratio']>0,t))
    # T07 triangle on finite distances
    tr=analyze_world(worlds['contextual_square']).transport_atlas['directed_cost']; ok=True
    states=worlds['contextual_square'].states
    for x in states:
      for y in states:
       for z in states:
        if tr[x][y]<float('inf') and tr[y][z]<float('inf'):
         ok=ok and tr[x][z] <= tr[x][y]+tr[y][z]+1e-9
    checks.append(("UM-T07",ok,{}))
    # T08
    checks.append(("UM-T08",len(c1)>=len(c0),{"class_gain":len(c1)-len(c0)}))
    # T09 rename invariance by class size multiset
    d=w.to_dict(); rename={s:f'n{i}' for i,s in enumerate(reversed(w.states))}
    d['states']=[rename[s] for s in w.states]; d['observations']={rename[s]:v for s,v in w.observations.items()}
    d['relations']={r:{rename[s]:{**e,"target":rename[e['target']]} for s,e in mp.items()} for r,mp in d['relations'].items()}
    wr=WorldSpec.from_dict(d); cr,_,_=quotient(wr,4)
    checks.append(("UM-T09",sorted(map(len,c))==sorted(map(len,cr)),{"original":list(map(len,c)),"renamed":list(map(len,cr))}))
    # T10
    checks.append(("UM-T10",set(a.dikwp_projection)=={'D','I','K','W','P'},{}))
    # T11 reflexive world has all states separated
    rr=analyze_world(worlds['reflexive_ruleworld'])
    checks.append(("UM-T11",len(rr.quotient)==len(worlds['reflexive_ruleworld'].states),{"classes":rr.quotient}))
    # T12
    types={x['type'] for x in a.proof_certificates}
    checks.append(("UM-T12",types=={'GENESIS','LOCAL_NECESSITY','WORLD_CONTACT','CO_UNDERSTANDING','NON_COLLAPSE','FORMAL_PROJECTION'},{}))
    return [{"id":i,"title":dict(REGISTRY)[i],"passed":bool(p),"evidence":e} for i,p,e in checks]
