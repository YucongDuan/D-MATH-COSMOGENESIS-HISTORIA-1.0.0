
from __future__ import annotations
from dataclasses import asdict
from pathlib import Path
import json
from .examples import worlds
from .core import analyze_world
from .theorems import run_checks, REGISTRY
from .ledger import append, save, verify
from .dashboard import render
from .models import WorldSpec, content_hash

def run_demo(out: Path):
    out.mkdir(parents=True,exist_ok=True)
    ws=worlds(); analyses=[]; ledger=[]
    for name,w in ws.items():
        a=analyze_world(w); d=asdict(a); analyses.append(d)
        (out/f'{name}.analysis.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
        append(ledger,'WORLD_ANALYZED',{"world_id":name,"world_hash":w.hash,"analysis_hash":a.analysis_hash})
    th=run_checks(ws)
    for t in th: append(ledger,'THEOREM_CHECKED',{"id":t['id'],"passed":t['passed']})
    save(out/'evidence_ledger.json',ledger)
    summary={"worlds":len(ws),"total_classes":sum(len(a['quotient']) for a in analyses),"witnesses":sum(len(a['distinguishing_witnesses']) for a in analyses),"theorems_passed":sum(t['passed'] for t in th),"theorems_total":len(th),"ledger_records":len(ledger)}
    data={"summary":summary,"analyses":analyses,"theorems":th,"ledger_verification":verify(ledger)}
    data['run_hash']=content_hash(data)
    (out/'reference_run.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    render(data,out/'dashboard.html')
    return data

def analyze_file(spec: Path, out: Path, depth:int=4):
    w=WorldSpec.from_dict(json.loads(spec.read_text(encoding='utf-8')))
    d=asdict(analyze_world(w,depth)); out.parent.mkdir(parents=True,exist_ok=True); out.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8'); return d

def verify_run(path: Path):
    if path.is_dir(): path=path/'evidence_ledger.json'
    records=json.loads(path.read_text(encoding='utf-8')); return verify(records)
