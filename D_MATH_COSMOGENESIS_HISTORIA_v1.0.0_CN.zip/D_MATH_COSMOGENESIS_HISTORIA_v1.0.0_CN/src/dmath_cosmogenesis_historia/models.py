
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any
import hashlib, json


def canonical_json(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def content_hash(obj: Any) -> str:
    return hashlib.sha256(canonical_json(obj).encode("utf-8")).hexdigest()

@dataclass(frozen=True)
class Edge:
    target: str
    cost: float = 1.0
    strength: float = 1.0

@dataclass
class WorldSpec:
    world_id: str
    states: list[str]
    relations: dict[str, dict[str, Edge]]
    observations: dict[str, str] = field(default_factory=dict)
    purposes: list[str] = field(default_factory=list)
    notes: str = ""

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "WorldSpec":
        rels: dict[str, dict[str, Edge]] = {}
        for r, mapping in d.get("relations", {}).items():
            rels[r] = {}
            for src, e in mapping.items():
                if isinstance(e, str):
                    rels[r][src] = Edge(e)
                else:
                    rels[r][src] = Edge(str(e["target"]), float(e.get("cost", 1.0)), float(e.get("strength", 1.0)))
        return cls(str(d["world_id"]), list(map(str,d["states"])), rels,
                   {str(k):str(v) for k,v in d.get("observations",{}).items()},
                   list(map(str,d.get("purposes",[]))), str(d.get("notes","")))

    def to_dict(self) -> dict[str, Any]:
        return {
            "world_id": self.world_id,
            "states": self.states,
            "relations": {r:{s:asdict(e) for s,e in m.items()} for r,m in self.relations.items()},
            "observations": self.observations,
            "purposes": self.purposes,
            "notes": self.notes,
        }

    @property
    def hash(self) -> str:
        return content_hash(self.to_dict())

@dataclass
class AnalysisResult:
    world_id: str
    world_hash: str
    depth: int
    quotient: list[list[str]]
    state_to_class: dict[str, int]
    distinguishing_witnesses: list[dict[str, Any]]
    congruence: dict[str, Any]
    time_atlas: dict[str, Any]
    transport_atlas: dict[str, Any]
    curvature_atlas: dict[str, Any]
    dikwp_projection: dict[str, Any]
    proof_certificates: list[dict[str, Any]]
    remainders: list[dict[str, Any]]
    analysis_hash: str = ""

    def finalize(self) -> "AnalysisResult":
        d=asdict(self); d.pop("analysis_hash",None)
        self.analysis_hash=content_hash(d)
        return self
