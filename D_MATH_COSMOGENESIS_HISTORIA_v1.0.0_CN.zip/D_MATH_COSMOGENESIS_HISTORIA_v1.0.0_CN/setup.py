from setuptools import setup, find_packages
setup(
 name='dmath-cosmogenesis-historia',
 version='1.0.0',
 description='Universe mathematics runtime based on anonymous continuation and future-equivalence quotient',
 packages=find_packages('src'),
 package_dir={'':'src'},
 python_requires='>=3.10',
 entry_points={'console_scripts':['cosmohistoria=dmath_cosmogenesis_historia.cli:main']},
)
